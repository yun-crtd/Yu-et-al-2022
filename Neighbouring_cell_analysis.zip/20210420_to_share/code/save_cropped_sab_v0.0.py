# ==================================================== README =========================================================
#
# Author: Gayathri Nadar, SCF MPI-CBG, nadar@mpi-cbg.de
#
# Version history:
#	09.03.2021 v0.0: get roi from user, cropped image to roi, get sabgal cells from user annotation, save its label map 
#					EXPECTED Image: file with 7 channels - c1-c3 is sabgal, c6 is hoechst and c7 is edu 
#
# Description:
#	This script asks the user to open a file of choice. The image is displayed and the user is asked to draw an ROI.
#	This region is cropped - the SABGAL image (c1-c3) is displayed and the user is asked to draw ROI around blue sabgal cells. This is then converted into a label map. 
#   Finally, the label image, cropped image with channels - c1-c3 (sabgal), c6 (hoechst), c7 (edu), sab label image, and sabgal cropped image is saved. 
# 
# Steps:
#	- open file with bio-formats
#	- create an image with 5 channels - c1-c3, c6 and c7 and display 
#	- ask user to draw roi 
#	- display cropped image with c1-c3 and ask user to draw sabgal cells 
#	- create label map 
#	- add selections to overlay 
#	- save images - cropped image with 5 channels, sabgal image with overlay, sabgal original image as composite, sabgal label image. 
#
# Usage:
#	- Open this script with FIJI
#	- Click run. In the window, set the file to process. Click ok. 
#
# Results:
# 	- Sabgal image - with three channels c1 - c3 
#	- Sabgal image with overlay of sabgal cells 
#	- Sabgal label map 
#	- Image with 5 relevant channels.
#
# =====================================================================================================================


# =====================================================================================================================
# Don't modify anything below here without good reason
# =====================================================================================================================


#@ File (label= "Select an image to process", style="file") impFile

from ij import IJ
from ij import ImagePlus
from ij.plugin import Duplicator, RGBStackMerge, ChannelSplitter
from ij.plugin.frame import RoiManager
from ij.measure import Measurements, ResultsTable
from ij.gui import Roi, PointRoi, WaitForUserDialog, Overlay
from ij.io import FileSaver 
import loci.plugins
from loci.plugins import BF
from loci.plugins.in import ImporterOptions 
from loci.formats import ImageReader
from java.awt import Color
import os, math
from os.path import isfile, join
import time, datetime 

rm = RoiManager.getInstance()
if not rm:
	rm = RoiManager()
rm.reset();

def main():
	# series could be set by user 
	imp = openImageWithBF(impFile.getPath(), virtual= True, seriesIdx = 3)
#	imp.show()

	impname = os.path.splitext(imp.getTitle())[0]
	cal = imp.getCalibration();

	# c1-c3 = RGB for SabGal = create composite 
	# c4-c6 = choose c6 = dapi 
	# c7-c9 = choose c7 = edu 
	sabgal = Duplicator().run(imp, 1, 3, 1, 1, 1, 1)
	dapi = Duplicator().run(imp, 6, 6, 1, 1, 1, 1)
	edu = Duplicator().run(imp, 7, 7, 1, 1, 1, 1)

	# get relevant channels 
	channels = ChannelSplitter().split(sabgal)
	channels.append(edu)
	channels.append(dapi)

	# create new image with 5 channels 
	imp1 = RGBStackMerge().mergeHyperstacks(channels, True) 
	imp1.setCalibration(cal)
	imp1.show()

	# get roi from user
	IJ.setTool("rectangle");
	WaitForUserDialog("Action required", "Please draw a ROI and press ok.").show() 
	roi = imp1.getRoi();
	imp1.hide()

	# crop image to roi set by user (if drawn), else whole image is duplicated 
	if roi is not None:
		imp1.setRoi(roi);
	imp_proc = Duplicator().run(imp1)
	imp_proc.setDisplayMode(IJ.COMPOSITE)
#	imp_proc.show()

	# show sabgal image and ask user to draw sabgal cells 
	sabgal1 = Duplicator().run(imp_proc, 1, 3, 1, 1, 1, 1)
	sabgal1.setDisplayMode(IJ.COMPOSITE)
	sabgal1.show()
	IJ.setTool("freehand");
	WaitForUserDialog("Action required", "Please draw one or more ROI around SABGAL+ cells. Draw a roi and press T. Repeat. Press ok when done.").show() 
	roiarray = rm.getRoisAsArray();
	sabgal1.hide() 

	# array to store centers of drawn cells 
	centers = []
	overlay = Overlay()

	# create a new empty image for generating a label map 
	sabgal_label = IJ.createImage("SABGAL_label", "16-bit black", imp_proc.getWidth(), imp_proc.getHeight(), 1);
#	sabgal_label.setCalibration(cal)
	ip = sabgal_label.getProcessor()

	# generate label map 
	for idx, roi in enumerate(roiarray):
		sabgal1.setRoi(roi)
		roi.setStrokeColor(Color.red);
		overlay.add(roi)

		# get center 
		stats = sabgal1.getStatistics(Measurements.ALL_STATS)
		cx_pixel = stats.xCentroid/cal.pixelWidth 
		cy_pixel = stats.yCentroid/cal.pixelWidth
		centers.append((cx_pixel, cy_pixel))

		p = PointRoi(int(cx_pixel), int(cy_pixel))
		overlay.add(p.clone())

		# add a label 
		ip.setColor(idx + 1)
		ip.fill(roi)

	ip.resetMinAndMax()
	IJ.run(sabgal_label, "glasbey on dark", "")
	sabgal_label.show()

	sabgal1_result = sabgal1.duplicate()
	sabgal1_result.setOverlay(overlay)
	sabgal1_result.setTitle("SABGAL-cells-overlay")
	sabgal1_result.show()

	# path to save results 
	ts = time.time() 
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y%m%d_%H-%M-%S')
	results_path = join(os.path.dirname(impFile.getPath()), st + "_" + impname + '_results')
	if not os.path.exists(results_path):
		os.makedirs(results_path)

	# keep other images (not needed for next steps) in separate folder
	other = join(results_path, "otherImages")
	if not os.path.exists(other):
		os.makedirs(other)

	# save all results 
	FileSaver(imp_proc).saveAsTiff(join(other, "cropped_" + impname + ".tif"))                             			# image with 5 channels 
	FileSaver(sabgal1).saveAsTiff(join(results_path, "sabgalcropped_" + impname + ".tif"))                          # sabgal image with 3 channels
	FileSaver(sabgal1_result).saveAsTiff(join(other, "sabgalcropped_overlay_" + impname + ".tif"))         			# sabgal with overlay 
	FileSaver(sabgal_label).saveAsTiff(join(results_path, "sabgal_labels_" + impname + ".tif"))                   	# sabgal cells label 

	# save also dapi and edu as separate images 
	edu1 = Duplicator().run(imp_proc, 4, 4, 1, 1, 1, 1)
	dapi1 = Duplicator().run(imp_proc, 5, 5, 1, 1, 1, 1)
	FileSaver(edu1).saveAsTiff(join(results_path, "edu_" + impname + ".tif"))
	FileSaver(dapi1).saveAsTiff(join(other, "hoechst_" + impname + ".tif"))

def openImageWithBF(path, virtual= True, seriesIdx = 1):
	"""
	set options to open image using bio-formats- use virtual for quick loading
	"""
	reader = ImageReader()
	reader.setId(path)
	seriesCount = reader.getSeriesCount()
	del reader 
	
	options = ImporterOptions()
	options.setColorMode(ImporterOptions.COLOR_MODE_COMPOSITE)
	options.setAutoscale(True)
	options.setStackFormat("Hyperstack")
	options.setVirtual(virtual)
	options.setSplitChannels(False) 
	if seriesCount > 1:
		options.setSeriesOn(seriesIdx - 1, True) 
	options.setId(path)
	
	imp = BF.openImagePlus(options)[0]

	return imp 

def createResultsFolder(imgdir, subfolders = None):
	"""
	Creates 'results' folder inside the image folder. Returns path imgdir/results
	It also creates subdirectories such that imgdir/results/sd1, imgdir/results/sd2... if specified.
	"""
	results_path = join(imgdir, 'results')
	
	if not os.path.exists(results_path):
		os.makedirs(results_path)

	if subfolders is not None:
		for sb in subfolders:
			if not os.path.exists(join(results_path, sb)):
				os.makedirs(join(results_path, sb))

	return results_path


main()
IJ.log("\\Clear")
print "Done"
rm.reset();
